﻿# DVSA Test Finder Sidebar

A Chrome extension side panel that keeps a persistent control surface open while you browse the DVSA practical test booking pages. It scans the current page for availability signals and highlights when date-like text or booking calls-to-action appear instead of the "No tests found on any date." message.

## Features
- Persistent side panel with start/stop and manual scan controls.
- Interval-based scanning that reads the page only (no form submissions).
- Visual status, last check time, and detected date snippets.
- Optional auto clicker for the "Show more results" button with interval + total clicks.
- Lightweight, local-only storage for running state.

## Load in Chrome
1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select the `dvsa-sidepanel-extension` folder.
5. Ensure you are on Chrome 114+ (side panel support). If clicking the icon does not open the panel, use the Chrome side panel drop-down and select **DVSA Test Finder Sidebar**.

## Use
1. Navigate to the DVSA practical test booking results page.
2. Click the extension icon to open the side panel.
3. Press **Start monitoring** and keep the panel open.
4. If the status shows **Dates detected**, review the DVSA page and book manually.
5. Use **Auto clicker** if you want to expand more results automatically.

## Notes
- The extension uses content script heuristics (text search + date patterns). If DVSA changes the layout, update `content.js` to add more precise selectors.
- This is a helper tool. Make sure you comply with DVSA terms of use.
