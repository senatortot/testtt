﻿const DEFAULT_INTERVAL_MS = 30000;
const NO_TESTS_REGEX = /(?:^|\s|[\u2013\u2014-])\s*No tests found on any date\.?/i;
const DATE_PATTERNS = [
  /\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)?\s?\d{1,2}\s(?:Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|Sept|September|Oct|October|Nov|November|Dec|December)\s?\d{2,4}?\b/gi,
  /\b\d{1,2}\/\d{1,2}\/\d{2,4}\b/gi,
  /\b\d{1,2}-\d{1,2}-\d{2,4}\b/gi
];
const CTA_REGEX = /\b(book|select|choose|reserve|available)\b/i;
const CLICK_TARGET_SELECTOR = "#fetch-more-centres";
const FIND_CENTRES_SELECTOR = "#test-centres-submit";
const CALENDAR_BOOKABLE_SELECTOR = "td.BookingCalendar-date--bookable a.BookingCalendar-dateLink";
const TIME_SLOT_SELECTOR = ".SlotPicker-day.is-active input.SlotPicker-slot[type=\"radio\"]";
const TIME_CONTAINER_SELECTOR = ".SlotPicker-timeSlots, .SlotPicker-days";
const SLOT_CONTINUE_SELECTOR = "input#slot-chosen-submit.button.cta";
const SLOT_WARNING_CONTINUE_SELECTOR = "button#slot-warning-continue.cta.dialog-action";
const CLICKER_DEFAULT_INTERVAL_MS = 125000;
const CLICKER_MAX_MISSES = 12;
const CLICKER_RANDOM_RATIO = 0.2;
const CLICKER_MIN_INTERVAL_MS = 2000;
const SUBMIT_DELAY_FLOOR_MS = 1000;
const SUBMIT_RETRY_MS = 2000;
const SUBMIT_MAX_MISSES = 10;
const AUTO_SCROLL_MIN_MS = 2000;
const AUTO_SCROLL_MAX_MS = 10000;
const AUTO_SCROLL_MIN_PAUSE_MS = 500;
const AUTO_SCROLL_MAX_PAUSE_MS = 3000;
const AUTO_SCROLL_MIN_DELTA_PX = 32;
const BLOCKED_MESSAGES = [
  { regex: /Access\s+Denied\.?/i, summary: "Access denied by the security service." },
  { regex: /Error\s*15\b/i, summary: "Access denied by the security service." },
  { regex: /You\s+have\s+been\s+blocked\s+by\s+DVSA\s+security\s+rules\.?/i, summary: "DVSA security rules blocked the request." },
  { regex: /Additional\s+security\s+check\s+is\s+required\.?/i, summary: "Security check or captcha required." },
  { regex: /This\s+request\s+was\s+blocked\s+by\s+our\s+security\s+service\.?/i, summary: "Request blocked by security service." },
  { regex: /Request\s+unsuccessful\.?\s*Incapsula\s+incident/i, summary: "Request blocked by security service." }
];
const BLOCKED_SELECTORS = [
  { selector: "div.error-title", regex: /Access\s+Denied/i, summary: "Access denied by the security service." },
  { selector: "div.error-code", regex: /Error\s*15\b/i, summary: "Access denied by the security service." },
  { selector: "p", regex: /Additional\s+security\s+check\s+is\s+required/i, summary: "Security check or captcha required." },
  { selector: "div.description", regex: /blocked by our security service|Additional security check is required/i, summary: "Request blocked by security service." },
  { selector: "div.error-description", regex: /blocked by our security service|Request unsuccessful/i, summary: "Request blocked by security service." }
];
const AVAILABILITY_SELECTOR = ".test-centre-details";
const AVAILABILITY_TEXT_REGEX = /available tests around\s*([0-9]{1,2}[\/-][0-9]{1,2}[\/-][0-9]{2,4})/i;
const DEFAULT_FILTERS = {
  centres: [],
  dateFrom: null,
  dateTo: null
};
const DEFAULT_AUTONAV = false;

let running = false;
let intervalId = null;
let intervalMs = DEFAULT_INTERVAL_MS;
let lastSignature = "";
let filters = { ...DEFAULT_FILTERS };
let autoNavigated = false;
let autoNavigateEnabled = DEFAULT_AUTONAV;
let blockedObserver = null;
let calendarObserver = null;
let calendarAutoClicked = false;
let calendarAutoClickedDate = null;
let timeObserver = null;
let timeAutoClickedDate = null;
let continueObserver = null;
let continueAutoClickedDate = null;
let warningObserver = null;
let warningAutoClickedDate = null;
let clicker = {
  running: false,
  timeoutId: null,
  submitTimeoutId: null,
  intervalMs: CLICKER_DEFAULT_INTERVAL_MS,
  totalClicks: 3,
  count: 0,
  lastClickAt: null,
  nextClickAt: null,
  nextIntervalMs: null,
  nextIntervalRandomized: false,
  startedAt: null,
  clickFindAfter: false,
  loop: false,
  autoScroll: false,
  cycle: 0,
  submitPending: false,
  submitAt: null,
  submitMissed: 0,
  missed: 0
};
let clickerObserver = null;
let pendingClick = false;
let autoScrollState = {
  running: false,
  timeoutId: null,
  rafId: null,
  startTime: 0,
  durationMs: 0,
  startY: 0,
  targetY: 0
};

function extractDates(text) {
  const matches = new Set();
  for (const pattern of DATE_PATTERNS) {
    pattern.lastIndex = 0;
    const results = text.matchAll(pattern);
    for (const match of results) {
      if (match[0]) {
        matches.add(match[0].trim());
      }
    }
  }
  return Array.from(matches).slice(0, 6);
}

function extractDatesFromText(text) {
  if (!text) {
    return [];
  }
  const matches = new Set();
  for (const pattern of DATE_PATTERNS) {
    pattern.lastIndex = 0;
    const results = text.matchAll(pattern);
    for (const match of results) {
      if (match[0]) {
        matches.add(match[0].trim());
      }
    }
  }
  return Array.from(matches);
}

function collectCentresFromDom() {
  const centres = new Set();
  document.querySelectorAll(AVAILABILITY_SELECTOR).forEach((block) => {
    const location = block.querySelector("h4")?.textContent?.trim();
    if (location) {
      centres.add(location);
    }
  });
  return Array.from(centres);
}

function normalizeCentreName(value) {
  return (value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function parseDateString(value) {
  if (!value) {
    return null;
  }
  const trimmed = value.trim();
  const isoMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
  if (isoMatch) {
    const year = Number(isoMatch[1]);
    const month = Number(isoMatch[2]) - 1;
    const day = Number(isoMatch[3]);
    return new Date(Date.UTC(year, month, day));
  }

  const dmyMatch = /^(\d{1,2})[\/-](\d{1,2})[\/-](\d{2,4})$/.exec(trimmed);
  if (dmyMatch) {
    let year = Number(dmyMatch[3]);
    if (year < 100) {
      year += 2000;
    }
    const month = Number(dmyMatch[2]) - 1;
    const day = Number(dmyMatch[1]);
    return new Date(Date.UTC(year, month, day));
  }

  const monthMatch = /(\d{1,2})\s*(Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|Sept|September|Oct|October|Nov|November|Dec|December)\s*(\d{2,4})?/i.exec(trimmed);
  if (monthMatch) {
    const day = Number(monthMatch[1]);
    const rawMonth = monthMatch[2].toLowerCase();
    const yearPart = monthMatch[3] ? Number(monthMatch[3]) : new Date().getUTCFullYear();
    const year = yearPart < 100 ? yearPart + 2000 : yearPart;
    const monthIndex = {
      jan: 0,
      january: 0,
      feb: 1,
      february: 1,
      mar: 2,
      march: 2,
      apr: 3,
      april: 3,
      may: 4,
      jun: 5,
      june: 5,
      jul: 6,
      july: 6,
      aug: 7,
      august: 7,
      sep: 8,
      sept: 8,
      september: 8,
      oct: 9,
      october: 9,
      nov: 10,
      november: 10,
      dec: 11,
      december: 11
    }[rawMonth];
    if (monthIndex !== undefined) {
      return new Date(Date.UTC(year, monthIndex, day));
    }
  }

  return null;
}

function isWithinRange(dateValue, from, to) {
  if (!dateValue) {
    return false;
  }
  const time = dateValue.getTime();
  if (from && time < from.getTime()) {
    return false;
  }
  if (to && time > to.getTime()) {
    return false;
  }
  return true;
}

function hasBookingCta() {
  const elements = document.querySelectorAll("button, a");
  return Array.from(elements).some((el) => CTA_REGEX.test(el.textContent || ""));
}

function extractAvailabilityDetails() {
  const entries = [];
  const seen = new Set();
  const centres = new Set();
  const blocks = document.querySelectorAll(AVAILABILITY_SELECTOR);

  const addEntry = (date, location) => {
    const key = `${normalizeCentreName(location)}|${date}`;
    if (seen.has(key)) {
      return;
    }
    seen.add(key);
    const label = location ? `${location} - ${date}` : date;
    entries.push({ date, location, label, dateObj: parseDateString(date) });
  };

  blocks.forEach((block) => {
    const location = block.querySelector("h4")?.textContent?.trim() || "";
    if (location) {
      centres.add(location);
    }
    const detailText = block.querySelector("h5")?.textContent || block.textContent || "";
    const normalized = detailText.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    const match = AVAILABILITY_TEXT_REGEX.exec(normalized);
    if (match?.[1]) {
      addEntry(match[1], location);
      return;
    }
    const fallbackDates = extractDatesFromText(normalized);
    fallbackDates.forEach((date) => addEntry(date, location));
  });

  return {
    entries,
    labels: entries.map((entry) => entry.label),
    dates: entries.map((entry) => entry.date),
    centres: Array.from(centres)
  };
}

function filterAvailabilityEntries(entries, filtersToApply) {
  const centreSet = new Set((filtersToApply.centres || []).map(normalizeCentreName));
  const from = parseDateString(filtersToApply.dateFrom);
  const to = parseDateString(filtersToApply.dateTo);
  return entries.filter((entry) => {
    const centreOk = centreSet.size === 0 || centreSet.has(normalizeCentreName(entry.location));
    const dateOk = !from && !to ? true : isWithinRange(entry.dateObj, from, to);
    return centreOk && dateOk;
  });
}

function filterDatesByRange(dates, filtersToApply) {
  const from = parseDateString(filtersToApply.dateFrom);
  const to = parseDateString(filtersToApply.dateTo);
  if (!from && !to) {
    return dates;
  }
  return dates.filter((date) => {
    const parsed = parseDateString(date);
    return isWithinRange(parsed, from, to);
  });
}

function matchesSelectorText(selector, regex) {
  return Array.from(document.querySelectorAll(selector)).some((node) => regex.test((node.textContent || "").trim()));
}

function getDocumentText() {
  const bodyText = document.body?.textContent || "";
  const htmlText = document.documentElement?.textContent || "";
  return bodyText.length >= htmlText.length ? bodyText : htmlText;
}

function detectBlockedSummary(bodyText) {
  const text = bodyText || getDocumentText();
  for (const entry of BLOCKED_MESSAGES) {
    if (entry.regex.test(text)) {
      return entry.summary;
    }
  }
  for (const entry of BLOCKED_SELECTORS) {
    if (matchesSelectorText(entry.selector, entry.regex)) {
      return entry.summary;
    }
  }
  return null;
}

function initBlockedWatcher() {
  notifyBlockedIfPresent("startup");
  startBlockedObserver();
}

function notifyBlockedIfPresent(reason) {
  const summary = detectBlockedSummary("");
  if (!summary) {
    return false;
  }
  const result = {
    status: "blocked",
    summary,
    dates: [],
    ctaFound: false,
    noTests: false,
    blocked: true,
    availabilityFound: false,
    centres: [],
    reason: reason || "blocked",
    checkedAt: new Date().toISOString()
  };
  sendResult(result);
  return true;
}

function startBlockedObserver() {
  if (blockedObserver) {
    return;
  }
  const target = document.documentElement || document.body;
  if (!target) {
    window.setTimeout(startBlockedObserver, 500);
    return;
  }
  blockedObserver = new MutationObserver(() => {
    notifyBlockedIfPresent("blocked_observer");
  });
  blockedObserver.observe(target, { childList: true, subtree: true, characterData: true });
}

function findFirstBookableDateLink() {
  return document.querySelector(CALENDAR_BOOKABLE_SELECTOR);
}

function maybeAutoSelectCalendarDate(reason) {
  if (!autoNavigateEnabled || calendarAutoClicked) {
    return false;
  }
  const link = findFirstBookableDateLink();
  if (!link) {
    return false;
  }
  calendarAutoClicked = true;
  calendarAutoClickedDate = link.getAttribute("data-date") || null;
  timeAutoClickedDate = null;
  link.scrollIntoView({ block: "center", inline: "center" });
  triggerElementClick(link);
  window.setTimeout(initTimeAutoSelect, 0);
  return true;
}

function startCalendarObserver() {
  if (calendarObserver) {
    return;
  }
  const target = document.body || document.documentElement;
  if (!target) {
    window.setTimeout(startCalendarObserver, 500);
    return;
  }
  calendarObserver = new MutationObserver(() => {
    if (maybeAutoSelectCalendarDate("calendar_observer")) {
      stopCalendarObserver();
    }
  });
  calendarObserver.observe(target, { childList: true, subtree: true });
}

function stopCalendarObserver() {
  if (calendarObserver) {
    calendarObserver.disconnect();
    calendarObserver = null;
  }
}

function getActiveDateKey() {
  const activeDay = document.querySelector(".SlotPicker-day.is-active");
  if (!activeDay) {
    return null;
  }
  const idMatch = /date-(\d{4}-\d{2}-\d{2})/.exec(activeDay.id || "");
  if (idMatch?.[1]) {
    return idMatch[1];
  }
  const titleId = activeDay.querySelector("[id^=\"SlotPicker-dayTitle-\"]")?.id || "";
  const titleMatch = /SlotPicker-dayTitle-(\d{4}-\d{2}-\d{2})/.exec(titleId);
  return titleMatch?.[1] || null;
}

function findFirstAvailableTimeInput(activeDay) {
  const root = activeDay || document;
  const inputs = Array.from(root.querySelectorAll("input.SlotPicker-slot[type=\"radio\"]"));
  return inputs.find((input) => !input.disabled) || null;
}

function maybeAutoSelectTime(reason) {
  if (!autoNavigateEnabled) {
    return false;
  }
  const activeDay = document.querySelector(".SlotPicker-day.is-active");
  const activeDateKey = getActiveDateKey();
  if (!calendarAutoClicked) {
    const firstDateLink = findFirstBookableDateLink();
    const firstDateKey = firstDateLink?.getAttribute("data-date") || null;
    if (firstDateKey && (!activeDateKey || firstDateKey !== activeDateKey)) {
      return false;
    }
  }
  if (calendarAutoClickedDate && activeDateKey && calendarAutoClickedDate !== activeDateKey) {
    return false;
  }
  const dateKey = activeDateKey || "__unknown__";
  if (timeAutoClickedDate === dateKey) {
    return false;
  }
  if (activeDay?.querySelector("input.SlotPicker-slot[type=\"radio\"]:checked")) {
    timeAutoClickedDate = dateKey;
    window.setTimeout(initContinueAutoClick, 0);
    return false;
  }
  const input = findFirstAvailableTimeInput(activeDay);
  if (!input) {
    return false;
  }
  timeAutoClickedDate = dateKey;
  input.scrollIntoView({ block: "center", inline: "center" });
  triggerElementClick(input);
  window.setTimeout(initContinueAutoClick, 0);
  return true;
}

function startTimeObserver() {
  if (timeObserver) {
    return;
  }
  const target = document.querySelector(TIME_CONTAINER_SELECTOR) || document.body || document.documentElement;
  if (!target) {
    window.setTimeout(startTimeObserver, 500);
    return;
  }
  timeObserver = new MutationObserver(() => {
    if (maybeAutoSelectTime("time_observer")) {
      stopTimeObserver();
    }
  });
  timeObserver.observe(target, { childList: true, subtree: true });
}

function stopTimeObserver() {
  if (timeObserver) {
    timeObserver.disconnect();
    timeObserver = null;
  }
}

function findContinueButton() {
  return document.querySelector(SLOT_CONTINUE_SELECTOR);
}

function shouldAutoClickContinueForDate(activeDateKey) {
  if (!autoNavigateEnabled) {
    return false;
  }
  if (!activeDateKey) {
    return false;
  }
  if (calendarAutoClickedDate && calendarAutoClickedDate !== activeDateKey) {
    return false;
  }
  return continueAutoClickedDate !== activeDateKey;
}

function maybeAutoClickContinue(reason) {
  if (!autoNavigateEnabled) {
    return false;
  }
  const activeDateKey = getActiveDateKey();
  if (!shouldAutoClickContinueForDate(activeDateKey)) {
    return false;
  }
  const checked = document.querySelector("input.SlotPicker-slot[type=\"radio\"]:checked");
  if (!checked) {
    return false;
  }
  const button = findContinueButton();
  if (!button || button.disabled) {
    return false;
  }
  continueAutoClickedDate = activeDateKey;
  button.scrollIntoView({ block: "center", inline: "center" });
  triggerElementClick(button);
  window.setTimeout(initWarningAutoClick, 0);
  return true;
}

function startContinueObserver() {
  if (continueObserver) {
    return;
  }
  const target = document.querySelector(TIME_CONTAINER_SELECTOR) || document.body || document.documentElement;
  if (!target) {
    window.setTimeout(startContinueObserver, 500);
    return;
  }
  continueObserver = new MutationObserver(() => {
    if (maybeAutoClickContinue("continue_observer")) {
      stopContinueObserver();
    }
  });
  continueObserver.observe(target, { childList: true, subtree: true });
}

function stopContinueObserver() {
  if (continueObserver) {
    continueObserver.disconnect();
    continueObserver = null;
  }
}

function findWarningContinueButton() {
  return document.querySelector(SLOT_WARNING_CONTINUE_SELECTOR);
}

function shouldAutoClickWarningForDate(activeDateKey) {
  if (!autoNavigateEnabled) {
    return false;
  }
  if (!activeDateKey) {
    return false;
  }
  if (calendarAutoClickedDate && calendarAutoClickedDate !== activeDateKey) {
    return false;
  }
  return warningAutoClickedDate !== activeDateKey;
}

function maybeAutoClickWarning(reason) {
  if (!autoNavigateEnabled) {
    return false;
  }
  const activeDateKey = getActiveDateKey();
  if (!shouldAutoClickWarningForDate(activeDateKey)) {
    return false;
  }
  const button = findWarningContinueButton();
  if (!button || button.disabled) {
    return false;
  }
  if (button.closest("[aria-hidden=\"true\"]")) {
    return false;
  }
  warningAutoClickedDate = activeDateKey;
  button.scrollIntoView({ block: "center", inline: "center" });
  triggerElementClick(button);
  return true;
}

function startWarningObserver() {
  if (warningObserver) {
    return;
  }
  const target = document.body || document.documentElement;
  if (!target) {
    window.setTimeout(startWarningObserver, 500);
    return;
  }
  warningObserver = new MutationObserver(() => {
    if (maybeAutoClickWarning("warning_observer")) {
      stopWarningObserver();
    }
  });
  warningObserver.observe(target, { childList: true, subtree: true });
}

function stopWarningObserver() {
  if (warningObserver) {
    warningObserver.disconnect();
    warningObserver = null;
  }
}

function initCalendarAutoSelect() {
  if (!autoNavigateEnabled) {
    stopCalendarObserver();
    stopTimeObserver();
    stopContinueObserver();
    stopWarningObserver();
    return;
  }
  if (maybeAutoSelectCalendarDate("calendar_init")) {
    stopCalendarObserver();
    return;
  }
  startCalendarObserver();
}

function initTimeAutoSelect() {
  if (!autoNavigateEnabled) {
    stopTimeObserver();
    stopContinueObserver();
    stopWarningObserver();
    return;
  }
  if (maybeAutoSelectTime("time_init")) {
    stopTimeObserver();
    return;
  }
  startTimeObserver();
}

function initContinueAutoClick() {
  if (!autoNavigateEnabled) {
    stopContinueObserver();
    return;
  }
  if (maybeAutoClickContinue("continue_init")) {
    stopContinueObserver();
    return;
  }
  startContinueObserver();
}

function initWarningAutoClick() {
  if (!autoNavigateEnabled) {
    stopWarningObserver();
    return;
  }
  if (maybeAutoClickWarning("warning_init")) {
    stopWarningObserver();
    return;
  }
  startWarningObserver();
}

function buildResult(reason) {
  const bodyText = document.body?.innerText || "";
  const blockedSummary = detectBlockedSummary("");
  const blocked = !!blockedSummary;
  const noTests = NO_TESTS_REGEX.test(bodyText);
  const availability = extractAvailabilityDetails();
  const availabilityLabels = availability.labels;
  const fallbackDates = extractDates(bodyText);
  const hasCentreFilter = (filters.centres?.length || 0) > 0;
  const filtersActive = hasCentreFilter || !!filters.dateFrom || !!filters.dateTo;
  const filteredEntries = filtersActive ? filterAvailabilityEntries(availability.entries, filters) : availability.entries;
  const filteredLabels = filteredEntries.map((entry) => entry.label);
  const filteredFallback = filterDatesByRange(fallbackDates, filters);
  let dates = [];
  if (filtersActive) {
    if (filteredLabels.length > 0) {
      dates = filteredLabels;
    } else if (!hasCentreFilter && filteredFallback.length > 0) {
      dates = filteredFallback;
    } else {
      dates = [];
    }
  } else {
    dates = availabilityLabels.length > 0 ? availabilityLabels : fallbackDates;
  }
  const ctaFound = hasBookingCta();

  let status = "unknown";
  let summary = "";

  if (blocked) {
    status = "blocked";
    summary = blockedSummary;
  } else if (filtersActive) {
    if (filteredLabels.length > 0) {
      status = "available";
      summary = "Availability matches your filters.";
    } else if (availability.entries.length > 0) {
      status = "none";
      summary = "No matching centres or dates yet.";
    } else if (filteredFallback.length > 0 && (filters.centres?.length || 0) === 0) {
      status = "available";
      summary = "Date-like text detected within your range.";
    } else if (noTests) {
      status = "none";
      summary = "No tests found message detected.";
    } else {
      status = "unknown";
      summary = "Waiting for matching availability.";
    }
  } else if (availabilityLabels.length > 0) {
    status = "available";
    summary = "Availability text detected in results.";
  } else if (fallbackDates.length > 0 || ctaFound) {
    status = "available";
    summary = fallbackDates.length > 0 ? "Date-like text detected on the page." : "Booking call-to-action detected.";
  } else if (noTests) {
    status = "none";
    summary = "No tests found message detected.";
  } else {
    status = "unknown";
    summary = "No dates detected yet.";
  }

  return {
    status,
    summary,
    dates,
    ctaFound,
    noTests,
    blocked,
    availabilityFound: availabilityLabels.length > 0,
    centres: availability.centres,
    reason,
    checkedAt: new Date().toISOString()
  };
}

function safeSendMessage(payload) {
  try {
    if (!chrome?.runtime?.id) {
      return;
    }
    chrome.runtime.sendMessage(payload, () => {
      void chrome.runtime.lastError;
    });
  } catch (error) {
    // Extension context can be invalidated during reloads; ignore.
  }
}

function sendResult(result) {
  const signature = JSON.stringify({ status: result.status, dates: result.dates, noTests: result.noTests, ctaFound: result.ctaFound });
  const changed = signature !== lastSignature;
  if (changed) {
    lastSignature = signature;
  }
  safeSendMessage({ type: "STATUS_UPDATE", result: { ...result, changed } });
}

function findAutoNavigateTarget() {
  const anchors = Array.from(document.querySelectorAll("a.test-centre-details-link"));
  if (anchors.length === 0) {
    return null;
  }
  const centreFilter = new Set((filters.centres || []).map(normalizeCentreName));
  const from = parseDateString(filters.dateFrom);
  const to = parseDateString(filters.dateTo);
  const hasCentreFilter = centreFilter.size > 0;
  const hasDateFilter = !!from || !!to;

  for (const anchor of anchors) {
    const details = anchor.querySelector(".test-centre-details") || anchor;
    const location = details.querySelector("h4")?.textContent?.trim() || "";
    const detailText = details.querySelector("h5")?.textContent || details.textContent || "";
    const normalized = detailText.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    const match = AVAILABILITY_TEXT_REGEX.exec(normalized);
    if (!match?.[1]) {
      continue;
    }
    const dateValue = parseDateString(match[1]);
    if (hasCentreFilter && !centreFilter.has(normalizeCentreName(location))) {
      continue;
    }
    if (hasDateFilter && !isWithinRange(dateValue, from, to)) {
      continue;
    }
    return { anchor, location, date: match[1] };
  }

  return null;
}

function stopAllAutomation() {
  stopScanning();
  stopClicker("auto_navigate");
  safeSendMessage({ type: "STOP_FROM_CONTENT" });
}

function maybeAutoNavigate(result) {
  if (!autoNavigateEnabled) {
    return;
  }
  if (autoNavigated) {
    return;
  }
  if (result.status !== "available") {
    return;
  }
  const target = findAutoNavigateTarget();
  if (!target) {
    return;
  }
  autoNavigated = true;
  stopAllAutomation();
  target.anchor.scrollIntoView({ block: "center", inline: "center" });
  target.anchor.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
}

function scanPage(reason = "auto") {
  const result = buildResult(reason);
  sendResult(result);
  maybeAutoNavigate(result);
}

function sendClickerStatus(reason, error, onSaved) {
  const payload = {
    running: clicker.running,
    intervalMs: clicker.intervalMs,
    totalClicks: clicker.totalClicks,
    count: clicker.count,
    lastClickAt: clicker.lastClickAt,
    nextClickAt: clicker.nextClickAt,
    nextIntervalMs: clicker.nextIntervalMs,
    nextIntervalRandomized: clicker.nextIntervalRandomized,
    startedAt: clicker.startedAt,
    clickFindAfter: clicker.clickFindAfter,
    loop: clicker.loop,
    autoScroll: clicker.autoScroll,
    cycle: clicker.cycle,
    submitPending: clicker.submitPending,
    submitAt: clicker.submitAt,
    submitMissed: clicker.submitMissed,
    reason,
    error: error || null
  };
  chrome.storage.local.set({ clicker: payload }, () => {
    void chrome.runtime.lastError;
    if (typeof onSaved === "function") {
      onSaved();
    }
  });
  safeSendMessage({
    type: "CLICKER_STATUS",
    clicker: {
      ...payload,
      found: !!document.querySelector(CLICK_TARGET_SELECTOR)
    }
  });
}

function clearScheduledSubmit() {
  if (clicker.submitTimeoutId) {
    window.clearTimeout(clicker.submitTimeoutId);
    clicker.submitTimeoutId = null;
  }
}

function triggerElementClick(element) {
  if (!element) {
    return false;
  }
  if (typeof element.click === "function") {
    element.click();
    return true;
  }
  element.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
  return true;
}

function getRandomizedIntervalMs(baseMs) {
  const baseValue = Number(baseMs) || CLICKER_DEFAULT_INTERVAL_MS;
  const minMs = Math.max(CLICKER_MIN_INTERVAL_MS, Math.round(baseValue * (1 - CLICKER_RANDOM_RATIO)));
  const maxMs = Math.max(minMs, Math.round(baseValue * (1 + CLICKER_RANDOM_RATIO)));
  return Math.floor(minMs + Math.random() * (maxMs - minMs + 1));
}

function setNextClickAt(anchorMs, randomized) {
  if (!Number.isFinite(anchorMs)) {
    return;
  }
  if (randomized) {
    const intervalMsValue = getRandomizedIntervalMs(clicker.intervalMs);
    clicker.nextIntervalMs = intervalMsValue;
    clicker.nextIntervalRandomized = true;
    clicker.nextClickAt = new Date(anchorMs + intervalMsValue).toISOString();
    return;
  }
  const intervalMsValue = Number(clicker.intervalMs) || CLICKER_DEFAULT_INTERVAL_MS;
  clicker.nextIntervalMs = intervalMsValue;
  clicker.nextIntervalRandomized = false;
  clicker.nextClickAt = new Date(anchorMs + intervalMsValue).toISOString();
}

function clickFindCentres() {
  const button = document.querySelector(FIND_CENTRES_SELECTOR);
  if (!button) {
    return false;
  }
  button.scrollIntoView({ block: "center", inline: "center" });
  return triggerElementClick(button);
}

function scheduleSubmitCheck() {
  if (!clicker.submitPending) {
    return;
  }
  const submitAtTime = clicker.submitAt ? new Date(clicker.submitAt).getTime() : Date.now();
  const delay = Math.max(0, submitAtTime - Date.now());
  clearScheduledSubmit();
  clicker.submitTimeoutId = window.setTimeout(() => {
    attemptSubmit();
  }, delay);
}

function attemptSubmit() {
  if (!clicker.submitPending) {
    return;
  }
  const submitAtTime = clicker.submitAt ? new Date(clicker.submitAt).getTime() : Date.now();
  if (Date.now() < submitAtTime) {
    scheduleSubmitCheck();
    return;
  }
  const button = document.querySelector(FIND_CENTRES_SELECTOR);
  if (!button) {
    clicker.submitMissed += 1;
    if (clicker.submitMissed >= SUBMIT_MAX_MISSES) {
      stopClicker("submit_not_found", "Find test centres button not found.");
      return;
    }
    clicker.submitAt = new Date(Date.now() + SUBMIT_RETRY_MS).toISOString();
    clicker.nextClickAt = clicker.submitAt;
    clicker.nextIntervalMs = SUBMIT_RETRY_MS;
    clicker.nextIntervalRandomized = false;
    sendClickerStatus("submit_waiting");
    scheduleSubmitCheck();
    return;
  }

  if (clicker.loop) {
    clicker.cycle = (clicker.cycle || 0) + 1;
    clicker.count = 0;
    clicker.lastClickAt = null;
    clicker.startedAt = new Date().toISOString();
    setNextClickAt(Date.now(), true);
    clicker.missed = 0;
    clicker.submitPending = false;
    clicker.submitAt = null;
    clicker.submitMissed = 0;
    sendClickerStatus("loop_submit", null, () => {
      button.scrollIntoView({ block: "center", inline: "center" });
      triggerElementClick(button);
      scheduleNextClick();
    });
    return;
  }

  clicker.running = false;
  clicker.nextClickAt = null;
  clicker.nextIntervalMs = null;
  clicker.nextIntervalRandomized = false;
  clicker.submitPending = false;
  clicker.submitAt = null;
  clicker.submitMissed = 0;
  sendClickerStatus("submit", null, () => {
    button.scrollIntoView({ block: "center", inline: "center" });
    triggerElementClick(button);
    stopObserver();
  });
}

function handleCompletion() {
  clearScheduledClick();
  clearScheduledSubmit();
  pendingClick = false;
  const shouldSubmit = clicker.clickFindAfter || clicker.loop;
  if (!shouldSubmit) {
    stopClicker("complete");
    return;
  }

  const delay = Math.max(SUBMIT_DELAY_FLOOR_MS, getRandomizedIntervalMs(clicker.intervalMs));
  clicker.submitPending = true;
  clicker.submitAt = new Date(Date.now() + delay).toISOString();
  clicker.submitMissed = 0;
  clicker.nextClickAt = clicker.submitAt;
  clicker.nextIntervalMs = delay;
  clicker.nextIntervalRandomized = true;
  sendClickerStatus("submit_scheduled");
  scheduleSubmitCheck();
}

function ensureObserver() {
  if (clickerObserver || !document.body) {
    return;
  }
  clickerObserver = new MutationObserver(() => {
    if (!clicker.running || !pendingClick) {
      return;
    }
    if (document.querySelector(CLICK_TARGET_SELECTOR)) {
      pendingClick = false;
      clickTarget("auto");
    }
  });
  clickerObserver.observe(document.body, { childList: true, subtree: true });
}

function stopObserver() {
  if (clickerObserver) {
    clickerObserver.disconnect();
    clickerObserver = null;
  }
}

function clearScheduledClick() {
  if (clicker.timeoutId) {
    window.clearTimeout(clicker.timeoutId);
    clicker.timeoutId = null;
  }
}

function getMaxScrollTop() {
  const doc = document.documentElement;
  const body = document.body;
  const scrollHeight = Math.max(body?.scrollHeight || 0, doc?.scrollHeight || 0);
  const clientHeight = window.innerHeight || doc?.clientHeight || 0;
  return Math.max(0, scrollHeight - clientHeight);
}

function getRandomInRange(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}

function pickScrollTarget(startY, maxScroll) {
  if (maxScroll <= 0) {
    return startY;
  }
  let target = Math.floor(Math.random() * (maxScroll + 1));
  if (Math.abs(target - startY) < AUTO_SCROLL_MIN_DELTA_PX) {
    const delta = Math.min(200, maxScroll);
    target = Math.min(maxScroll, Math.max(0, startY + (Math.random() < 0.5 ? -delta : delta)));
  }
  return target;
}

function shouldAutoScroll() {
  return clicker.running && clicker.autoScroll;
}

function stopAutoScroll() {
  autoScrollState.running = false;
  if (autoScrollState.timeoutId) {
    window.clearTimeout(autoScrollState.timeoutId);
    autoScrollState.timeoutId = null;
  }
  if (autoScrollState.rafId) {
    window.cancelAnimationFrame(autoScrollState.rafId);
    autoScrollState.rafId = null;
  }
}

function scheduleAutoScroll(delayMs) {
  if (!shouldAutoScroll()) {
    stopAutoScroll();
    return;
  }
  if (autoScrollState.timeoutId) {
    window.clearTimeout(autoScrollState.timeoutId);
  }
  autoScrollState.timeoutId = window.setTimeout(() => {
    beginAutoScroll();
  }, Math.max(0, delayMs));
}

function startAutoScroll() {
  if (autoScrollState.running) {
    return;
  }
  autoScrollState.running = true;
  scheduleAutoScroll(0);
}

function beginAutoScroll() {
  if (!shouldAutoScroll()) {
    stopAutoScroll();
    return;
  }
  const maxScroll = getMaxScrollTop();
  if (maxScroll <= 0) {
    scheduleAutoScroll(getRandomInRange(AUTO_SCROLL_MIN_PAUSE_MS, AUTO_SCROLL_MAX_PAUSE_MS));
    return;
  }
  const currentY = Math.max(0, Math.min(window.scrollY || 0, maxScroll));
  const targetY = pickScrollTarget(currentY, maxScroll);
  if (targetY === currentY) {
    scheduleAutoScroll(getRandomInRange(AUTO_SCROLL_MIN_PAUSE_MS, AUTO_SCROLL_MAX_PAUSE_MS));
    return;
  }
  autoScrollState.startY = currentY;
  autoScrollState.targetY = targetY;
  autoScrollState.durationMs = getRandomInRange(AUTO_SCROLL_MIN_MS, AUTO_SCROLL_MAX_MS);
  autoScrollState.startTime = performance.now();
  if (autoScrollState.rafId) {
    window.cancelAnimationFrame(autoScrollState.rafId);
  }
  autoScrollState.rafId = window.requestAnimationFrame(stepAutoScroll);
}

function stepAutoScroll(timestamp) {
  if (!shouldAutoScroll()) {
    stopAutoScroll();
    return;
  }
  const elapsed = timestamp - autoScrollState.startTime;
  const duration = Math.max(1, autoScrollState.durationMs);
  const t = Math.min(1, elapsed / duration);
  const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
  const nextY = autoScrollState.startY + (autoScrollState.targetY - autoScrollState.startY) * eased;
  window.scrollTo(0, Math.round(nextY));
  if (t < 1) {
    autoScrollState.rafId = window.requestAnimationFrame(stepAutoScroll);
  } else {
    autoScrollState.rafId = null;
    scheduleAutoScroll(getRandomInRange(AUTO_SCROLL_MIN_PAUSE_MS, AUTO_SCROLL_MAX_PAUSE_MS));
  }
}

function updateAutoScrollState() {
  if (shouldAutoScroll()) {
    startAutoScroll();
  } else {
    stopAutoScroll();
  }
}

function clickTarget(reason) {
  clearScheduledClick();
  clearScheduledSubmit();
  pendingClick = false;
  const target = document.querySelector(CLICK_TARGET_SELECTOR);
  if (!target) {
    clicker.missed += 1;
    setNextClickAt(Date.now(), true);
    if (clicker.missed >= CLICKER_MAX_MISSES) {
      stopClicker("not_found", "Show more results button not found.");
    } else {
      pendingClick = true;
      ensureObserver();
      sendClickerStatus("not_found_retry");
      scheduleNextClick();
    }
    return;
  }

  clicker.missed = 0;
  target.scrollIntoView({ block: "center", inline: "center" });
  clicker.count += 1;
  clicker.lastClickAt = new Date().toISOString();
  setNextClickAt(Date.now(), true);
  sendClickerStatus(reason, null, () => {
    target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
    if (clicker.count >= clicker.totalClicks) {
      handleCompletion();
    } else {
      scheduleNextClick();
    }
  });
}

function scheduleNextClick() {
  if (!clicker.running) {
    return;
  }
  if (clicker.submitPending) {
    scheduleSubmitCheck();
    return;
  }
  let nextAt = clicker.nextClickAt ? new Date(clicker.nextClickAt).getTime() : 0;
  if (!nextAt) {
    const anchor = clicker.lastClickAt || clicker.startedAt;
    const anchorMs = anchor ? new Date(anchor).getTime() : Date.now();
    setNextClickAt(anchorMs, true);
    nextAt = clicker.nextClickAt ? new Date(clicker.nextClickAt).getTime() : 0;
    sendClickerStatus("scheduled");
  }
  const delay = Math.max(0, nextAt - Date.now());
  clearScheduledClick();
  clicker.timeoutId = window.setTimeout(() => clickTarget("auto"), delay);
}

function startClicker(ms, totalClicks, options = {}) {
  if (clicker.running) {
    return;
  }
  const intervalMsValue = Number(ms) || clicker.intervalMs;
  const totalClicksValue = Number(totalClicks) || 1;

  clicker.running = true;
  clicker.intervalMs = intervalMsValue;
  clicker.totalClicks = totalClicksValue;
  const resumeCount = Number(options.count);
  clicker.count = Number.isFinite(resumeCount) ? resumeCount : 0;
  clicker.lastClickAt = options.lastClickAt || null;
  clicker.startedAt = options.startedAt || new Date().toISOString();
  clicker.nextClickAt = options.nextClickAt || new Date(Date.now() + clicker.intervalMs).toISOString();
  clicker.nextIntervalMs = options.nextIntervalMs || null;
  clicker.nextIntervalRandomized = !!options.nextIntervalRandomized;
  clicker.clickFindAfter = !!options.clickFindAfter;
  clicker.loop = !!options.loop;
  clicker.autoScroll = !!options.autoScroll;
  clicker.cycle = Number.isFinite(Number(options.cycle)) ? Number(options.cycle) : 0;
  clicker.submitPending = !!options.submitPending;
  clicker.submitAt = options.submitAt || null;
  clicker.submitMissed = Number.isFinite(Number(options.submitMissed)) ? Number(options.submitMissed) : 0;
  clicker.missed = 0;
  pendingClick = false;
  clearScheduledSubmit();
  ensureObserver();

  updateAutoScrollState();
  sendClickerStatus(options.resume ? "resume" : "start");
  if (options.resume) {
    if (clicker.submitPending) {
      scheduleSubmitCheck();
    } else {
      scheduleNextClick();
    }
  } else {
    clickTarget("start");
  }
}

function stopClicker(reason = "stop", error) {
  clearScheduledClick();
  clearScheduledSubmit();
  clicker.running = false;
  clicker.nextClickAt = null;
  clicker.submitPending = false;
  clicker.submitAt = null;
  clicker.submitMissed = 0;
  pendingClick = false;
  stopObserver();
  stopAutoScroll();
  sendClickerStatus(reason, error);
}

function startScanning(ms) {
  if (running) {
    return;
  }
  autoNavigated = false;
  running = true;
  intervalMs = Number(ms) || intervalMs;
  scanPage("start");
  intervalId = window.setInterval(() => scanPage("auto"), intervalMs);
}

function stopScanning() {
  running = false;
  if (intervalId) {
    window.clearInterval(intervalId);
    intervalId = null;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type) {
    return;
  }

  if (message.type === "CONTROL") {
    if (message.action === "START") {
      startScanning(message.intervalMs);
      sendResponse({ ok: true });
      return;
    }

    if (message.action === "STOP") {
      stopScanning();
      sendResponse({ ok: true });
      return;
    }

    if (message.action === "SCAN_NOW") {
      scanPage("manual");
      sendResponse({ ok: true });
    }
  }

  if (message.type === "CLICKER") {
    if (message.action === "START") {
      startClicker(message.intervalMs, message.totalClicks, {
        clickFindAfter: message.clickFindAfter,
        loop: message.loop,
        autoScroll: message.autoScroll
      });
      sendResponse({ ok: true });
      return;
    }

    if (message.action === "STOP") {
      stopClicker("stop");
      sendResponse({ ok: true });
    }
  }

  if (message.type === "CLICKER_PREFS") {
    if (typeof message.autoScroll === "boolean") {
      const changed = clicker.autoScroll !== message.autoScroll;
      clicker.autoScroll = message.autoScroll;
      updateAutoScrollState();
      if (changed && clicker.running) {
        sendClickerStatus("prefs");
      }
    }
    sendResponse({ ok: true });
  }

  if (message.type === "FILTERS_UPDATE") {
    filters = { ...DEFAULT_FILTERS, ...(message.filters || {}) };
    autoNavigated = false;
    scanPage("filters");
    sendResponse({ ok: true });
  }

  if (message.type === "AUTONAV_UPDATE") {
    const wasEnabled = autoNavigateEnabled;
    autoNavigateEnabled = !!message.autoNavigate;
    autoNavigated = false;
    if (autoNavigateEnabled && !wasEnabled) {
      calendarAutoClicked = false;
      calendarAutoClickedDate = null;
      timeAutoClickedDate = null;
      continueAutoClickedDate = null;
      warningAutoClickedDate = null;
    }
    initCalendarAutoSelect();
    initTimeAutoSelect();
    initContinueAutoClick();
    initWarningAutoClick();
    sendResponse({ ok: true });
  }

  if (message.type === "REFRESH_CENTRES") {
    const centres = collectCentresFromDom();
    sendResponse({ ok: true, centres });
  }
});

chrome.storage.local.get({
  running: false,
  intervalMs: DEFAULT_INTERVAL_MS,
  autoNavigate: DEFAULT_AUTONAV,
  filters: DEFAULT_FILTERS,
  clicker: {
    running: false,
    intervalMs: CLICKER_DEFAULT_INTERVAL_MS,
    totalClicks: 3,
    count: 0,
    lastClickAt: null,
    nextClickAt: null,
    nextIntervalMs: null,
    nextIntervalRandomized: false,
    startedAt: null,
    clickFindAfter: false,
    loop: false,
    autoScroll: false,
    cycle: 0,
    submitPending: false,
    submitAt: null,
    submitMissed: 0
  }
}).then((state) => {
  autoNavigateEnabled = !!state.autoNavigate;
  filters = { ...DEFAULT_FILTERS, ...(state.filters || {}) };
  if (state.running) {
    startScanning(state.intervalMs);
  }
  const storedClicker = state.clicker || {};
  if (storedClicker.running) {
    const needsSubmit = !!storedClicker.submitPending
      || (storedClicker.count >= storedClicker.totalClicks && (storedClicker.loop || storedClicker.clickFindAfter));
    const resumeInterval = Number(storedClicker.intervalMs) || CLICKER_DEFAULT_INTERVAL_MS;
    let resumeSubmitAt = storedClicker.submitAt || null;
    let resumeNextIntervalMs = storedClicker.nextIntervalMs || null;
    let resumeNextIntervalRandomized = !!storedClicker.nextIntervalRandomized;
    if (needsSubmit && !resumeSubmitAt) {
      const resumeDelay = Math.max(SUBMIT_DELAY_FLOOR_MS, getRandomizedIntervalMs(resumeInterval));
      resumeSubmitAt = new Date(Date.now() + resumeDelay).toISOString();
      if (!resumeNextIntervalMs) {
        resumeNextIntervalMs = resumeDelay;
        resumeNextIntervalRandomized = true;
      }
    }
    startClicker(storedClicker.intervalMs, storedClicker.totalClicks, {
      resume: true,
      count: storedClicker.count,
      lastClickAt: storedClicker.lastClickAt,
      nextClickAt: storedClicker.nextClickAt,
      nextIntervalMs: resumeNextIntervalMs,
      nextIntervalRandomized: resumeNextIntervalRandomized,
      startedAt: storedClicker.startedAt,
      clickFindAfter: storedClicker.clickFindAfter,
      loop: storedClicker.loop,
      autoScroll: storedClicker.autoScroll,
      cycle: storedClicker.cycle,
      submitPending: needsSubmit,
      submitAt: resumeSubmitAt,
      submitMissed: storedClicker.submitMissed
    });
  }
  initBlockedWatcher();
  initCalendarAutoSelect();
  initTimeAutoSelect();
  initContinueAutoClick();
  initWarningAutoClick();
});
