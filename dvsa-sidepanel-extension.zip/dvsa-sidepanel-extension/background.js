﻿const DEFAULT_STATE = {
  running: false,
  intervalMs: 30000,
  lastResult: null,
  clicker: {
    running: false,
    intervalMs: 125000,
    totalClicks: 3,
    count: 0,
    lastClickAt: null,
    nextClickAt: null,
    nextIntervalMs: null,
    nextIntervalRandomized: false,
    startedAt: null,
    clickFindAfter: false,
    loop: false,
    autoScroll: false,
    cycle: 0,
    submitPending: false,
    submitAt: null,
    submitMissed: 0,
    error: null
  },
  filters: {
    centres: [],
    dateFrom: null,
    dateTo: null
  },
  autoNavigate: false
};

if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}

let targetTabId = null;

async function openSidePanel(tab) {
  if (!chrome.sidePanel?.open) {
    return;
  }
  const targetWindowId = tab?.windowId;
  if (targetWindowId) {
    await chrome.sidePanel.open({ windowId: targetWindowId });
  }
}

async function getState() {
  return await chrome.storage.local.get(DEFAULT_STATE);
}

async function setState(partial) {
  await chrome.storage.local.set(partial);
  const state = await getState();
  broadcast({ type: "STATE_UPDATE", state });
  return state;
}

async function updateClicker(partial) {
  const state = await getState();
  const clicker = {
    ...DEFAULT_STATE.clicker,
    ...(state.clicker || {}),
    ...(partial || {})
  };
  await setState({ clicker });
  broadcast({ type: "CLICKER_STATUS", clicker });
  return clicker;
}

function broadcast(message) {
  chrome.runtime.sendMessage(message);
}

function updateBadge(state, result) {
  if (!state.running) {
    chrome.action.setBadgeText({ text: "" });
    return;
  }

  if (result?.status === "available") {
    chrome.action.setBadgeText({ text: "GO" });
    chrome.action.setBadgeBackgroundColor({ color: "#1b7f5a" });
    return;
  }

  chrome.action.setBadgeText({ text: "ON" });
  chrome.action.setBadgeBackgroundColor({ color: "#2f4b7c" });
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id || null;
}

function sendToTab(tabId, message) {
  if (!tabId) {
    return Promise.resolve({ ok: false, error: "No active tab found." });
  }
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const error = chrome.runtime.lastError?.message;
      if (error) {
        resolve({ ok: false, error });
        return;
      }
      resolve({ ok: true, response });
    });
  });
}

async function sendToTargetTab(message) {
  const tabId = targetTabId || await getActiveTabId();
  return sendToTab(tabId, message);
}

function isFromTarget(sender) {
  if (!sender?.tab?.id) {
    return false;
  }
  if (sender.frameId !== undefined && sender.frameId !== 0) {
    return false;
  }
  if (targetTabId && sender.tab.id !== targetTabId) {
    return false;
  }
  return true;
}

chrome.runtime.onInstalled.addListener(async () => {
  const seeded = await chrome.storage.local.get(DEFAULT_STATE);
  await chrome.storage.local.set(seeded);

  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
});

chrome.runtime.onStartup.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
});

chrome.action.onClicked.addListener((tab) => {
  openSidePanel(tab);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type) {
    return;
  }

  if (message.type === "GET_STATE") {
    getState().then(sendResponse);
    return true;
  }

  if (message.type === "START") {
    const intervalMs = Number(message.intervalMs) || DEFAULT_STATE.intervalMs;
    (async () => {
      const tabId = await getActiveTabId();
      if (!tabId) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }
      const result = await sendToTab(tabId, { type: "CONTROL", action: "START", intervalMs });
      if (!result.ok) {
        const state = await setState({ running: false });
        updateBadge(state, state.lastResult);
        sendResponse({ ok: false, error: result.error });
        return;
      }
      targetTabId = tabId;
      const state = await setState({ running: true, intervalMs });
      updateBadge(state, state.lastResult);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.type === "STOP") {
    (async () => {
      const result = await sendToTargetTab({ type: "CONTROL", action: "STOP" });
      targetTabId = null;
      const state = await setState({ running: false });
      updateBadge(state, state.lastResult);
      sendResponse({ ok: result.ok, error: result.error });
    })();
    return true;
  }

  if (message.type === "SCAN_NOW") {
    sendToTargetTab({ type: "CONTROL", action: "SCAN_NOW" }).then((result) => {
      sendResponse({ ok: result.ok, error: result.error });
    });
    return true;
  }

  if (message.type === "CLICKER_START") {
    const intervalMs = Math.max(2000, Number(message.intervalMs) || DEFAULT_STATE.clicker.intervalMs);
    const totalClicks = Math.max(1, Number(message.totalClicks) || 1);
    const clickFindAfter = !!message.clickFindAfter;
    const loop = !!message.loop;
    const autoScroll = !!message.autoScroll;
    const normalizedClickFind = clickFindAfter || loop;
    (async () => {
      const tabId = targetTabId || await getActiveTabId();
      if (!tabId) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }
      const result = await sendToTab(tabId, { type: "CLICKER", action: "START", intervalMs, totalClicks, clickFindAfter: normalizedClickFind, loop, autoScroll });
      if (result.ok) {
        targetTabId = tabId;
        const startedAt = new Date().toISOString();
        updateClicker({
          running: true,
          intervalMs,
          totalClicks,
          count: 0,
          startedAt,
          nextClickAt: new Date(Date.now() + intervalMs).toISOString(),
          clickFindAfter: normalizedClickFind,
          loop,
          autoScroll,
          error: null
        });
      }
      sendResponse({ ok: result.ok, error: result.error });
    })();
    return true;
  }

  if (message.type === "CLICKER_STOP") {
    sendToTargetTab({ type: "CLICKER", action: "STOP" }).then((result) => {
      if (result.ok) {
        updateClicker({ running: false, nextClickAt: null, nextIntervalMs: null, nextIntervalRandomized: false, error: null });
      }
      sendResponse({ ok: result.ok, error: result.error });
    });
    return true;
  }

  if (message.type === "CLICKER_PREFS") {
    const loopProvided = typeof message.loop === "boolean";
    const clickFindProvided = typeof message.clickFindAfter === "boolean";
    const loop = loopProvided ? message.loop : undefined;
    const clickFindAfter = clickFindProvided ? message.clickFindAfter : undefined;
    const intervalMsValue = Number(message.intervalMs);
    const totalClicksValue = Number(message.totalClicks);
    const autoScroll = typeof message.autoScroll === "boolean" ? message.autoScroll : undefined;
    const update = {};
    if (loopProvided) {
      update.loop = loop;
    }
    if (clickFindProvided) {
      update.clickFindAfter = clickFindAfter;
    }
    if (loopProvided && loop) {
      update.clickFindAfter = true;
    }
    if (Number.isFinite(intervalMsValue) && intervalMsValue > 0) {
      update.intervalMs = Math.max(2000, intervalMsValue);
    }
    if (Number.isFinite(totalClicksValue) && totalClicksValue > 0) {
      update.totalClicks = Math.max(1, totalClicksValue);
    }
    if (autoScroll !== undefined) {
      update.autoScroll = autoScroll;
    }
    updateClicker(update).then(() => {
      if (autoScroll !== undefined) {
        sendToTargetTab({ type: "CLICKER_PREFS", autoScroll });
      }
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "SET_FILTERS") {
    const filters = {
      centres: Array.isArray(message.filters?.centres) ? message.filters.centres : [],
      dateFrom: message.filters?.dateFrom || null,
      dateTo: message.filters?.dateTo || null
    };
    setState({ filters }).then(() => {
      sendToTargetTab({ type: "FILTERS_UPDATE", filters }).then((result) => {
        sendResponse({ ok: result.ok, error: result.error });
      });
    });
    return true;
  }

  if (message.type === "SET_AUTONAV") {
    const autoNavigate = !!message.autoNavigate;
    setState({ autoNavigate }).then(() => {
      sendToTargetTab({ type: "AUTONAV_UPDATE", autoNavigate }).then((result) => {
        sendResponse({ ok: result.ok, error: result.error });
      });
    });
    return true;
  }

  if (message.type === "REFRESH_CENTRES") {
    sendToTargetTab({ type: "REFRESH_CENTRES" }).then((result) => {
      sendResponse({ ok: result.ok, error: result.error, centres: result.response?.centres || [] });
    });
    return true;
  }

  if (message.type === "STATUS_UPDATE") {
    if (!isFromTarget(sender)) {
      return;
    }
    const result = message.result || null;
    setState({ lastResult: result }).then((state) => {
      updateBadge(state, result);
      broadcast({ type: "STATUS_UPDATE", result });
    });
  }

  if (message.type === "STOP_FROM_CONTENT") {
    if (!isFromTarget(sender)) {
      return;
    }
    targetTabId = null;
    setState({ running: false }).then((state) => {
      updateBadge(state, state.lastResult);
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "CLICKER_STATUS") {
    if (!isFromTarget(sender)) {
      return;
    }
    const clicker = message.clicker || null;
    updateClicker(clicker);
  }
});

