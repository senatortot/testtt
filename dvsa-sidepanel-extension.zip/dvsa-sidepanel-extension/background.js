﻿const DEFAULT_STATE = {
  running: false,
  intervalMs: 30000,
  lastResult: null,
  clicker: {
    running: false,
    intervalMs: 125000,
    totalClicks: 3,
    count: 0,
    lastClickAt: null,
    nextClickAt: null,
    nextIntervalMs: null,
    nextIntervalRandomized: false,
    startedAt: null,
    clickFindAfter: false,
    loop: false,
    autoScroll: false,
    cycle: 0,
    submitPending: false,
    submitAt: null,
    submitMissed: 0,
    error: null
  },
  filters: {
    centres: [],
    dateFrom: null,
    dateTo: null
  },
  autoNavigate: false,
  licenseKey: null,
  expiresAt: null,
  isActive: false,
  lastValidatedAt: null
};

const LICENSE_STORAGE_DEFAULTS = {
  licenseKey: null,
  expiresAt: null,
  isActive: false,
  lastValidatedAt: null
};

const LICENSE_API_BASE = "https://testfinder.io/wp-json/lmfwc/v2/licenses/activate/";
const LICENSE_AUTH_HEADER = "Basic Y2tfMzJlZGE3YzljM2E4NjUyYmVkMzVjOTRiMzM2MGY1ODczZjkyOWNkYzpjc184MDIzZDJlMzc1YzYxOTUxMGMwM2I1ODFiMjdmMjRhZjkyOTFlM2Zi";
const LICENSE_KEY_REGEX = /^[A-Z0-9]{4}(-[A-Z0-9]{4}){3}$/;
const LICENSE_MESSAGE_INVALID = "\u274C Invalid license key";
const LICENSE_MESSAGE_EXPIRED = "\u23F0 License expired";
const LICENSE_MESSAGE_ACTIVE = "\u2705 License active";
const LICENSE_GUARD_MESSAGE = "Enter a valid license to unlock";

if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}

let targetTabId = null;

function normalizeLicenseKey(value) {
  return (value || "").trim().toUpperCase();
}

async function getLicenseState() {
  return await chrome.storage.local.get(LICENSE_STORAGE_DEFAULTS);
}

async function setLicenseState(partial) {
  await chrome.storage.local.set(partial);
  return await getLicenseState();
}

function parseLicenseErrors(errors) {
  if (!errors) {
    return null;
  }
  const errorKeys = Object.keys(errors || {});
  const errorText = JSON.stringify(errors || {}).toLowerCase();
  const isExpired = errorKeys.some((key) => key.includes("expired")) || errorText.includes("expired");
  if (isExpired) {
    return { status: "expired", message: LICENSE_MESSAGE_EXPIRED };
  }
  return { status: "invalid", message: LICENSE_MESSAGE_INVALID };
}

async function validateLicenseKey(rawKey) {
  const normalized = normalizeLicenseKey(rawKey);
  if (!LICENSE_KEY_REGEX.test(normalized)) {
    return {
      ok: true,
      status: "invalid",
      isActive: false,
      message: LICENSE_MESSAGE_INVALID
    };
  }

  let payload = null;
  try {
    const response = await fetch(`${LICENSE_API_BASE}${encodeURIComponent(normalized)}`, {
      method: "GET",
      headers: {
        Authorization: LICENSE_AUTH_HEADER
      },
      cache: "no-store"
    });
    payload = await response.json();
  } catch (error) {
    return {
      ok: false,
      status: "error",
      isActive: false,
      message: "\u26A0\uFE0F License validation failed"
    };
  }

  const data = payload?.data || {};
  const errors = data.errors || data.error_data;
  if (payload?.success === true && !errors && data.expiresAt) {
    return {
      ok: true,
      status: "active",
      isActive: true,
      licenseKey: data.licenseKey || normalized,
      expiresAt: data.expiresAt,
      message: `${LICENSE_MESSAGE_ACTIVE} (expires: ${data.expiresAt})`
    };
  }

  if (errors) {
    const errorResult = parseLicenseErrors(errors);
    return {
      ok: true,
      status: errorResult?.status || "invalid",
      isActive: false,
      message: errorResult?.message || LICENSE_MESSAGE_INVALID
    };
  }

  return {
    ok: true,
    status: "invalid",
    isActive: false,
    message: LICENSE_MESSAGE_INVALID
  };
}

async function persistLicenseResult(result, previousState) {
  const lastValidatedAt = new Date().toISOString();
  if (result?.isActive) {
    return await setLicenseState({
      licenseKey: result.licenseKey || null,
      expiresAt: result.expiresAt || null,
      isActive: true,
      lastValidatedAt
    });
  }
  if (result?.status === "error") {
    return await setLicenseState({
      licenseKey: previousState?.licenseKey || null,
      expiresAt: previousState?.expiresAt || null,
      isActive: false,
      lastValidatedAt
    });
  }
  return await setLicenseState({
    licenseKey: null,
    expiresAt: null,
    isActive: false,
    lastValidatedAt
  });
}

async function enforceLicenseLock() {
  if (targetTabId) {
    sendToTab(targetTabId, { type: "CONTROL", action: "STOP" });
    sendToTab(targetTabId, { type: "CLICKER", action: "STOP" });
  }
  targetTabId = null;
  const state = await setState({ running: false });
  updateBadge(state, state.lastResult);
  await updateClicker({
    running: false,
    nextClickAt: null,
    nextIntervalMs: null,
    nextIntervalRandomized: false,
    error: null
  });
}

async function validateStoredLicense(reason) {
  const stored = await getLicenseState();
  if (!stored.licenseKey) {
    return null;
  }
  const result = await validateLicenseKey(stored.licenseKey);
  const updated = await persistLicenseResult(result, stored);
  if (!result.isActive) {
    await enforceLicenseLock();
  }
  return { result, updated, reason };
}

async function isLicenseActive() {
  const stored = await getLicenseState();
  return !!stored.isActive;
}

async function openSidePanel(tab) {
  if (!chrome.sidePanel?.open) {
    return;
  }
  const targetWindowId = tab?.windowId;
  if (targetWindowId) {
    await chrome.sidePanel.open({ windowId: targetWindowId });
  }
}

async function getState() {
  return await chrome.storage.local.get(DEFAULT_STATE);
}

async function setState(partial) {
  await chrome.storage.local.set(partial);
  const state = await getState();
  broadcast({ type: "STATE_UPDATE", state });
  return state;
}

async function updateClicker(partial) {
  const state = await getState();
  const clicker = {
    ...DEFAULT_STATE.clicker,
    ...(state.clicker || {}),
    ...(partial || {})
  };
  await setState({ clicker });
  broadcast({ type: "CLICKER_STATUS", clicker });
  return clicker;
}

function broadcast(message) {
  chrome.runtime.sendMessage(message);
}

function updateBadge(state, result) {
  if (!state.running) {
    chrome.action.setBadgeText({ text: "" });
    return;
  }

  if (result?.status === "available") {
    chrome.action.setBadgeText({ text: "GO" });
    chrome.action.setBadgeBackgroundColor({ color: "#1b7f5a" });
    return;
  }

  chrome.action.setBadgeText({ text: "ON" });
  chrome.action.setBadgeBackgroundColor({ color: "#2f4b7c" });
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id || null;
}

function sendToTab(tabId, message) {
  if (!tabId) {
    return Promise.resolve({ ok: false, error: "No active tab found." });
  }
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const error = chrome.runtime.lastError?.message;
      if (error) {
        resolve({ ok: false, error });
        return;
      }
      resolve({ ok: true, response });
    });
  });
}

async function sendToTargetTab(message) {
  const tabId = targetTabId || await getActiveTabId();
  return sendToTab(tabId, message);
}

function isFromTarget(sender) {
  if (!sender?.tab?.id) {
    return false;
  }
  if (sender.frameId !== undefined && sender.frameId !== 0) {
    return false;
  }
  if (targetTabId && sender.tab.id !== targetTabId) {
    return false;
  }
  return true;
}

chrome.runtime.onInstalled.addListener(async () => {
  const seeded = await chrome.storage.local.get(DEFAULT_STATE);
  await chrome.storage.local.set(seeded);

  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
});

chrome.runtime.onStartup.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
  validateStoredLicense("startup");
});

chrome.action.onClicked.addListener((tab) => {
  openSidePanel(tab);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type) {
    return;
  }

  if (message.type === "GET_STATE") {
    getState().then(sendResponse);
    return true;
  }

  if (message.type === "START") {
    const intervalMs = Number(message.intervalMs) || DEFAULT_STATE.intervalMs;
    (async () => {
      if (!await isLicenseActive()) {
        sendResponse({ ok: false, error: LICENSE_GUARD_MESSAGE });
        return;
      }
      const tabId = await getActiveTabId();
      if (!tabId) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }
      const result = await sendToTab(tabId, { type: "CONTROL", action: "START", intervalMs });
      if (!result.ok) {
        const state = await setState({ running: false });
        updateBadge(state, state.lastResult);
        sendResponse({ ok: false, error: result.error });
        return;
      }
      targetTabId = tabId;
      const state = await setState({ running: true, intervalMs });
      updateBadge(state, state.lastResult);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message.type === "STOP") {
    (async () => {
      const result = await sendToTargetTab({ type: "CONTROL", action: "STOP" });
      targetTabId = null;
      const state = await setState({ running: false });
      updateBadge(state, state.lastResult);
      sendResponse({ ok: result.ok, error: result.error });
    })();
    return true;
  }

  if (message.type === "SCAN_NOW") {
    (async () => {
      if (!await isLicenseActive()) {
        sendResponse({ ok: false, error: LICENSE_GUARD_MESSAGE });
        return;
      }
      const result = await sendToTargetTab({ type: "CONTROL", action: "SCAN_NOW" });
      sendResponse({ ok: result.ok, error: result.error });
    })();
    return true;
  }

  if (message.type === "CLICKER_START") {
    const intervalMs = Math.max(2000, Number(message.intervalMs) || DEFAULT_STATE.clicker.intervalMs);
    const totalClicks = Math.max(1, Number(message.totalClicks) || 1);
    const clickFindAfter = !!message.clickFindAfter;
    const loop = !!message.loop;
    const autoScroll = !!message.autoScroll;
    const normalizedClickFind = clickFindAfter || loop;
    (async () => {
      if (!await isLicenseActive()) {
        sendResponse({ ok: false, error: LICENSE_GUARD_MESSAGE });
        return;
      }
      const tabId = targetTabId || await getActiveTabId();
      if (!tabId) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }
      const result = await sendToTab(tabId, { type: "CLICKER", action: "START", intervalMs, totalClicks, clickFindAfter: normalizedClickFind, loop, autoScroll });
      if (result.ok) {
        targetTabId = tabId;
        const startedAt = new Date().toISOString();
        updateClicker({
          running: true,
          intervalMs,
          totalClicks,
          count: 0,
          startedAt,
          nextClickAt: new Date(Date.now() + intervalMs).toISOString(),
          clickFindAfter: normalizedClickFind,
          loop,
          autoScroll,
          error: null
        });
      }
      sendResponse({ ok: result.ok, error: result.error });
    })();
    return true;
  }

  if (message.type === "CLICKER_STOP") {
    sendToTargetTab({ type: "CLICKER", action: "STOP" }).then((result) => {
      if (result.ok) {
        updateClicker({ running: false, nextClickAt: null, nextIntervalMs: null, nextIntervalRandomized: false, error: null });
      }
      sendResponse({ ok: result.ok, error: result.error });
    });
    return true;
  }

  if (message.type === "CLICKER_PREFS") {
    (async () => {
      if (!await isLicenseActive()) {
        sendResponse({ ok: false, error: LICENSE_GUARD_MESSAGE });
        return;
      }
      const loopProvided = typeof message.loop === "boolean";
      const clickFindProvided = typeof message.clickFindAfter === "boolean";
      const loop = loopProvided ? message.loop : undefined;
      const clickFindAfter = clickFindProvided ? message.clickFindAfter : undefined;
      const intervalMsValue = Number(message.intervalMs);
      const totalClicksValue = Number(message.totalClicks);
      const autoScroll = typeof message.autoScroll === "boolean" ? message.autoScroll : undefined;
      const update = {};
      if (loopProvided) {
        update.loop = loop;
      }
      if (clickFindProvided) {
        update.clickFindAfter = clickFindAfter;
      }
      if (loopProvided && loop) {
        update.clickFindAfter = true;
      }
      if (Number.isFinite(intervalMsValue) && intervalMsValue > 0) {
        update.intervalMs = Math.max(2000, intervalMsValue);
      }
      if (Number.isFinite(totalClicksValue) && totalClicksValue > 0) {
        update.totalClicks = Math.max(1, totalClicksValue);
      }
      if (autoScroll !== undefined) {
        update.autoScroll = autoScroll;
      }
      updateClicker(update).then(() => {
        if (autoScroll !== undefined) {
          sendToTargetTab({ type: "CLICKER_PREFS", autoScroll });
        }
        sendResponse({ ok: true });
      });
    })();
    return true;
  }

  if (message.type === "SET_FILTERS") {
    (async () => {
      if (!await isLicenseActive()) {
        sendResponse({ ok: false, error: LICENSE_GUARD_MESSAGE });
        return;
      }
      const filters = {
        centres: Array.isArray(message.filters?.centres) ? message.filters.centres : [],
        dateFrom: message.filters?.dateFrom || null,
        dateTo: message.filters?.dateTo || null
      };
      setState({ filters }).then(() => {
        sendToTargetTab({ type: "FILTERS_UPDATE", filters }).then((result) => {
          sendResponse({ ok: result.ok, error: result.error });
        });
      });
    })();
    return true;
  }

  if (message.type === "SET_AUTONAV") {
    (async () => {
      if (!await isLicenseActive()) {
        sendResponse({ ok: false, error: LICENSE_GUARD_MESSAGE });
        return;
      }
      const autoNavigate = !!message.autoNavigate;
      setState({ autoNavigate }).then(() => {
        sendToTargetTab({ type: "AUTONAV_UPDATE", autoNavigate }).then((result) => {
          sendResponse({ ok: result.ok, error: result.error });
        });
      });
    })();
    return true;
  }

  if (message.type === "REFRESH_CENTRES") {
    (async () => {
      if (!await isLicenseActive()) {
        sendResponse({ ok: false, error: LICENSE_GUARD_MESSAGE });
        return;
      }
      const result = await sendToTargetTab({ type: "REFRESH_CENTRES" });
      sendResponse({ ok: result.ok, error: result.error, centres: result.response?.centres || [] });
    })();
    return true;
  }

  if (message.type === "LICENSE_VALIDATE") {
    (async () => {
      const current = await getLicenseState();
      const result = await validateLicenseKey(message.licenseKey);
      const updated = await persistLicenseResult(result, current);
      if (!result.isActive) {
        await enforceLicenseLock();
      }
      sendResponse({
        ok: result.ok !== false,
        result: {
          status: result.status,
          isActive: !!result.isActive,
          licenseKey: updated.licenseKey || null,
          expiresAt: updated.expiresAt || null,
          lastValidatedAt: updated.lastValidatedAt || null,
          message: result.message
        }
      });
    })();
    return true;
  }

  if (message.type === "STATUS_UPDATE") {
    if (!isFromTarget(sender)) {
      return;
    }
    const result = message.result || null;
    setState({ lastResult: result }).then((state) => {
      updateBadge(state, result);
      broadcast({ type: "STATUS_UPDATE", result });
    });
  }

  if (message.type === "STOP_FROM_CONTENT") {
    if (!isFromTarget(sender)) {
      return;
    }
    targetTabId = null;
    setState({ running: false }).then((state) => {
      updateBadge(state, state.lastResult);
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "CLICKER_STATUS") {
    if (!isFromTarget(sender)) {
      return;
    }
    const clicker = message.clicker || null;
    updateClicker(clicker);
  }
});

