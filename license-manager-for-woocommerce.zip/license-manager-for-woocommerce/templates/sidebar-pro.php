<?php defined('ABSPATH') || exit; ?>
<?php if (function_exists('lmfwc_is_pro') && lmfwc_is_pro()) { return; } ?>

<div class="lmfwc-sidebar">
    <div class="lmfwc-card lmfwc-pro-card">
        <div class="lmfwc-pro-header">
            <h3><?php esc_html_e('Unlock Pro Features', 'license-manager-for-woocommerce'); ?></h3>
            <span class="lmfwc-pro-badge">PRO</span>
        </div>
        <p><?php esc_html_e('Take your license management to the next level with these powerful features:', 'license-manager-for-woocommerce'); ?></p>
        
        <ul class="lmfwc-pro-features">
            <li>
                <span class="dashicons dashicons-yes"></span>
                <?php esc_html_e('Subscription Renewals', 'license-manager-for-woocommerce'); ?>
            </li>
            <li>
                <span class="dashicons dashicons-yes"></span>
                <?php esc_html_e('Customer License Validation', 'license-manager-for-woocommerce'); ?>
            </li>
            <li>
                <span class="dashicons dashicons-yes"></span>
                <?php esc_html_e('Download Expiry Management', 'license-manager-for-woocommerce'); ?>
            </li>
            <li>
                <span class="dashicons dashicons-yes"></span>
                <?php esc_html_e('Advanced Reporting', 'license-manager-for-woocommerce'); ?>
            </li>
            <li>
                <span class="dashicons dashicons-yes"></span>
                <?php esc_html_e('Priority Support', 'license-manager-for-woocommerce'); ?>
            </li>
        </ul>

        <a href="https://licensemanager.at/pricing/?utm_source=plugin&utm_medium=sidebar&utm_campaign=go_pro" target="_blank" class="shine-button  lmfwc-btn lmfwc-btn-primary lmfwc-btn-block">
            <?php esc_html_e('Upgrade to Pro', 'license-manager-for-woocommerce'); ?>
        </a>
    </div>

       
    <div class="lmfwc-card">
        <h3><?php esc_html_e('Need Help?', 'license-manager-for-woocommerce'); ?></h3>
        <p><?php esc_html_e('Check out our documentation or contact support if you have any questions.', 'license-manager-for-woocommerce'); ?></p>
        <a href="https://licensemanager.at/docs/?utm_source=plugin&utm_medium=sidebar&utm_campaign=docs" target="_blank" class="lmfwc-btn lmfwc-btn-secondary lmfwc-btn-block">
            <?php esc_html_e('View Documentation', 'license-manager-for-woocommerce'); ?>
        </a>
    </div>
</div>
