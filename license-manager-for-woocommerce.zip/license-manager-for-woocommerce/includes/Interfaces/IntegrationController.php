<?php

namespace LicenseManagerForWooCommerce\Interfaces;

defined('ABSPATH') || exit();

interface IntegrationController
{
}