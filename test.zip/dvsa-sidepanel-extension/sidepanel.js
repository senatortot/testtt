﻿const state = {
  running: false,
  intervalMs: 30000,
  lastResult: null,
  centres: [],
  filters: {
    centres: [],
    dateFrom: null,
    dateTo: null
  },
  autoNavigate: false,
  clicker: {
    running: false,
    intervalMs: 125000,
    totalClicks: 3,
    count: 0,
    lastClickAt: null,
    nextClickAt: null,
    nextIntervalMs: null,
    nextIntervalRandomized: false,
    startedAt: null,
    clickFindAfter: false,
    loop: false,
    autoScroll: false,
    cycle: 0,
    submitPending: false,
    submitAt: null,
    submitMissed: 0,
    error: null
  }
};

const elements = {
  statusPill: document.getElementById("status-pill"),
  statusPillText: document.getElementById("status-pill-text"),
  statusInfo: document.getElementById("status-info"),
  statusDot: document.getElementById("status-dot"),
  statusText: document.getElementById("status-text"),
  statusSummary: document.getElementById("status-summary"),
  lastChecked: document.getElementById("last-checked"),
  signalCount: document.getElementById("signal-count"),
  dateList: document.getElementById("date-list"),
  datesBlock: document.getElementById("dates-block"),
  startBtn: document.getElementById("start-btn"),
  stopBtn: document.getElementById("stop-btn"),
  intervalInput: document.getElementById("interval-input"),
  clickerStart: document.getElementById("clicker-start"),
  clickerStop: document.getElementById("clicker-stop"),
  clickerInterval: document.getElementById("clicker-interval"),
  clickerTotal: document.getElementById("clicker-total"),
  clickerProgress: document.getElementById("clicker-progress"),
  clickerNext: document.getElementById("clicker-next"),
  clickerSubmitAfter: document.getElementById("clicker-submit-after"),
  clickerLoop: document.getElementById("clicker-loop"),
  clickerAutoScroll: document.getElementById("clicker-autoscroll"),
  clickerChip: document.getElementById("clicker-chip"),
  filterChip: document.getElementById("filter-chip"),
  filterInfo: document.getElementById("filter-info"),
  centreSelect: document.getElementById("centre-select"),
  dateFrom: document.getElementById("date-from"),
  dateTo: document.getElementById("date-to"),
  filtersApply: document.getElementById("filters-apply"),
  filtersClear: document.getElementById("filters-clear"),
  centresRefresh: document.getElementById("centres-refresh"),
  autoNavToggle: document.getElementById("autonav-toggle"),
  errorBanner: document.getElementById("error-banner"),
  logList: document.getElementById("log-list")
};

const STATUS_LOOKUP = {
  available: {
    label: "Dates detected",
    summary: "Possible availability found. Review the DVSA page.",
    pill: "Available",
    tooltip: "Availability text or booking signals detected on the page.",
    dot: "#1b7f5a"
  },
  blocked: {
    label: "Blocked",
    summary: "DVSA security rules blocked access on this IP.",
    pill: "Blocked",
    tooltip: "Security or captcha page detected (access blocked).",
    dot: "#b3472e"
  },
  none: {
    label: "No dates",
    summary: "The page says no tests are available.",
    pill: "None",
    tooltip: "The page explicitly says no tests are available.",
    dot: "#9c2f2f"
  },
  unknown: {
    label: "Scanning",
    summary: "No clear signal yet.",
    pill: "Scanning",
    tooltip: "Monitoring is on but no clear signal yet.",
    dot: "#9aa4b2"
  },
  idle: {
    label: "Waiting",
    summary: "Press start when the DVSA results page is open.",
    pill: "Idle",
    tooltip: "Monitoring is off.",
    dot: "#9aa4b2"
  }
};

let audioContext = null;
let lastSoundAt = 0;
let lastWarningAt = 0;
let countdownTimer = null;
let fallbackNextAt = 0;
let filtersDirty = false;

function getAudioContext() {
  if (!audioContext) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) {
      return null;
    }
    audioContext = new AudioContextClass();
  }
  return audioContext;
}

function primeAudio() {
  const context = getAudioContext();
  if (!context) {
    return;
  }
  if (context.state === "suspended") {
    context.resume().catch(() => {});
  }
}

function playChiptune() {
  const context = getAudioContext();
  if (!context) {
    return;
  }
  const now = context.currentTime;
  const cooldownMs = 6000;
  if (Date.now() - lastSoundAt < cooldownMs) {
    return;
  }
  lastSoundAt = Date.now();

  const notes = [
    { freq: 659.25, dur: 0.12 },
    { freq: 987.77, dur: 0.12 },
    { freq: 1318.51, dur: 0.14 },
    { freq: 987.77, dur: 0.12 },
    { freq: 739.99, dur: 0.12 },
    { freq: 1108.73, dur: 0.12 },
    { freq: 1479.98, dur: 0.14 },
    { freq: 1108.73, dur: 0.12 },
    { freq: 783.99, dur: 0.12 },
    { freq: 1174.66, dur: 0.12 },
    { freq: 1567.98, dur: 0.15 },
    { freq: 1174.66, dur: 0.12 },
    { freq: 698.46, dur: 0.12 },
    { freq: 1046.5, dur: 0.12 },
    { freq: 1396.91, dur: 0.14 },
    { freq: 1046.5, dur: 0.12 },
    { freq: 830.61, dur: 0.12 },
    { freq: 1244.51, dur: 0.12 },
    { freq: 1661.22, dur: 0.16 },
    { freq: 1244.51, dur: 0.12 },
    { freq: 739.99, dur: 0.12 },
    { freq: 1108.73, dur: 0.12 },
    { freq: 1479.98, dur: 0.14 },
    { freq: 1108.73, dur: 0.12 },
    { freq: 880, dur: 0.12 },
    { freq: 1318.51, dur: 0.14 },
    { freq: 1760, dur: 0.16 },
    { freq: 1318.51, dur: 0.12 }
  ];

  let t = now;
  notes.forEach((note) => {
    const lead = context.createOscillator();
    const body = context.createOscillator();
    const gain = context.createGain();
    lead.type = "square";
    body.type = "triangle";
    lead.frequency.setValueAtTime(note.freq, t);
    body.frequency.setValueAtTime(note.freq / 2, t);
    lead.detune.setValueAtTime(6, t);
    body.detune.setValueAtTime(-4, t);
    gain.gain.setValueAtTime(0.16, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + note.dur);
    lead.connect(gain);
    body.connect(gain);
    gain.connect(context.destination);
    lead.start(t);
    body.start(t);
    lead.stop(t + note.dur);
    body.stop(t + note.dur);
    t += note.dur + 0.02;
  });
}

function playWarningChiptune() {
  const context = getAudioContext();
  if (!context) {
    return;
  }
  const cooldownMs = 5000;
  if (Date.now() - lastWarningAt < cooldownMs) {
    return;
  }
  lastWarningAt = Date.now();
  const now = context.currentTime;
  const notes = [
    { freq: 920, dur: 0.09 },
    { freq: 690, dur: 0.09 },
    { freq: 920, dur: 0.09 },
    { freq: 690, dur: 0.09 },
    { freq: 1040, dur: 0.12 }
  ];
  let t = now;
  notes.forEach((note) => {
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.type = "square";
    osc.frequency.setValueAtTime(note.freq, t);
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + note.dur);
    osc.connect(gain).connect(context.destination);
    osc.start(t);
    osc.stop(t + note.dur);
    t += note.dur + 0.03;
  });
}

function formatTime(isoString) {
  if (!isoString) {
    return "--";
  }
  const date = new Date(isoString);
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function setStatus(statusKey) {
  const config = STATUS_LOOKUP[statusKey] || STATUS_LOOKUP.unknown;
  elements.statusText.textContent = config.label;
  elements.statusSummary.textContent = config.summary;
  elements.statusPillText.textContent = config.pill;
  if (elements.statusInfo) {
    elements.statusInfo.dataset.tooltip = config.tooltip || "Status details unavailable.";
  }
  elements.statusDot.style.background = config.dot;
  elements.statusDot.style.boxShadow = `0 0 0 6px ${config.dot}33`;
}

function updateDates(dates) {
  elements.dateList.innerHTML = "";
  if (!dates || dates.length === 0) {
    elements.datesBlock.style.display = "none";
    return;
  }

  elements.datesBlock.style.display = "block";
  dates.forEach((date) => {
    const pill = document.createElement("span");
    pill.className = "date-pill";
    pill.textContent = date;
    elements.dateList.appendChild(pill);
  });
}

function updateControls() {
  elements.startBtn.disabled = state.running;
  elements.stopBtn.disabled = !state.running;
}

function updateClickerUI() {
  const clicker = state.clicker || {};
  elements.clickerStart.disabled = !!clicker.running;
  elements.clickerStop.disabled = !clicker.running;
  elements.clickerChip.textContent = clicker.running ? "On" : "Off";
  if (document.activeElement !== elements.clickerInterval) {
    elements.clickerInterval.value = Math.round((clicker.intervalMs || 125000) / 1000);
  }
  if (document.activeElement !== elements.clickerTotal) {
    elements.clickerTotal.value = clicker.totalClicks || 3;
  }
  elements.clickerSubmitAfter.checked = !!clicker.clickFindAfter;
  elements.clickerLoop.checked = !!clicker.loop;
  elements.clickerSubmitAfter.disabled = !!clicker.loop;
  elements.clickerAutoScroll.checked = !!clicker.autoScroll;
  elements.clickerProgress.textContent = `${clicker.count || 0} / ${clicker.totalClicks || 0}`;
  updateClickerCountdown();
  if (clicker.running) {
    startCountdownTimer();
  } else {
    fallbackNextAt = 0;
    stopCountdownTimer();
  }
}

function readClickerInputs() {
  const intervalSec = Number(elements.clickerInterval.value);
  const totalClicks = Number(elements.clickerTotal.value);
  const intervalMs = Number.isFinite(intervalSec) && intervalSec > 0
    ? Math.min(Math.max(intervalSec, 2), 300) * 1000
    : state.clicker?.intervalMs;
  const total = Number.isFinite(totalClicks) && totalClicks > 0
    ? Math.min(Math.max(totalClicks, 1), 100)
    : state.clicker?.totalClicks;
  return { intervalMs, total };
}

function syncClickerPrefs(clickFindAfter, loop, autoScroll) {
  const { intervalMs, total } = readClickerInputs();
  const autoScrollEnabled = typeof autoScroll === "boolean"
    ? autoScroll
    : !!elements.clickerAutoScroll.checked;
  if (Number.isFinite(intervalMs)) {
    state.clicker.intervalMs = intervalMs;
  }
  if (Number.isFinite(total)) {
    state.clicker.totalClicks = total;
  }
  state.clicker.autoScroll = autoScrollEnabled;
  sendMessage({
    type: "CLICKER_PREFS",
    clickFindAfter,
    loop,
    autoScroll: autoScrollEnabled,
    intervalMs,
    totalClicks: total
  });
}

function syncAutoScrollPref(autoScroll) {
  const autoScrollEnabled = !!autoScroll;
  state.clicker.autoScroll = autoScrollEnabled;
  sendMessage({ type: "CLICKER_PREFS", autoScroll: autoScrollEnabled });
}

function updateFilterChip() {
  const hasCentres = (state.filters.centres || []).length > 0;
  const hasDates = !!state.filters.dateFrom || !!state.filters.dateTo;
  if (!hasCentres && !hasDates) {
    elements.filterChip.textContent = "All";
    if (elements.filterInfo) {
      elements.filterInfo.dataset.tooltip = "No filters applied.";
    }
    return;
  }
  if (hasCentres && hasDates) {
    elements.filterChip.textContent = "Filtered";
    if (elements.filterInfo) {
      elements.filterInfo.dataset.tooltip = "Filtering by selected centres and date range.";
    }
    return;
  }
  elements.filterChip.textContent = hasCentres ? "Centres" : "Dates";
  if (elements.filterInfo) {
    elements.filterInfo.dataset.tooltip = hasCentres
      ? "Filtering by selected centres only."
      : "Filtering by date range only.";
  }
}

function updateCentresList(centres, selectedOverride) {
  if (!Array.isArray(centres)) {
    return;
  }
  const detected = Array.from(new Set(centres)).filter(Boolean).sort((a, b) => a.localeCompare(b));
  state.centres = detected;
  const selectedSource = Array.isArray(selectedOverride) ? selectedOverride : (state.filters.centres || []);
  const selectedList = Array.from(new Set(selectedSource)).filter(Boolean);
  const selectedSet = new Set(selectedList);
  const combined = [...selectedList, ...detected.filter((centre) => !selectedSet.has(centre))];
  elements.centreSelect.innerHTML = "";
  if (combined.length === 0) {
    const option = document.createElement("option");
    option.textContent = "No centres detected yet";
    option.disabled = true;
    elements.centreSelect.appendChild(option);
    return;
  }
  combined.forEach((centre) => {
    const option = document.createElement("option");
    option.value = centre;
    option.dataset.label = centre;
    option.dataset.saved = detected.includes(centre) ? "false" : "true";
    option.selected = selectedSet.has(centre);
    elements.centreSelect.appendChild(option);
  });
  updateCentreOptionLabels();
}

function updateCentreOptionLabels() {
  Array.from(elements.centreSelect.options).forEach((option) => {
    const base = option.dataset.label;
    if (!base) {
      return;
    }
    const saved = option.dataset.saved === "true";
    const prefix = option.selected ? "[x] " : "";
    const suffix = saved ? " (saved)" : "";
    option.textContent = `${prefix}${base}${suffix}`;
  });
}

function markFiltersDirty() {
  filtersDirty = true;
}

function updateFiltersUI(options = {}) {
  const filters = state.filters || {};
  const preserveDraft = options.preserveDraft ?? false;
  const selectedOverride = preserveDraft ? getSelectedCentres() : null;
  if (!preserveDraft) {
    elements.dateFrom.value = filters.dateFrom || "";
    elements.dateTo.value = filters.dateTo || "";
  }
  elements.autoNavToggle.checked = !!state.autoNavigate;
  updateCentresList(options.centres || state.centres || [], selectedOverride);
  updateDateConstraints();
  updateFilterChip();
}

function updateDateConstraints() {
  const fromValue = elements.dateFrom.value || "";
  const toValue = elements.dateTo.value || "";
  elements.dateFrom.max = toValue || "";
  elements.dateTo.min = fromValue || "";
}

function reconcileDateRange(changedField) {
  const fromValue = elements.dateFrom.value || "";
  const toValue = elements.dateTo.value || "";
  if (!fromValue || !toValue) {
    updateDateConstraints();
    return;
  }
  if (fromValue > toValue) {
    if (changedField === "from") {
      elements.dateTo.value = fromValue;
    } else {
      elements.dateFrom.value = toValue;
    }
  }
  updateDateConstraints();
}

function getSelectedCentres() {
  return Array.from(elements.centreSelect.selectedOptions || []).map((option) => option.value);
}

async function applyFilters() {
  const filters = {
    centres: getSelectedCentres(),
    dateFrom: elements.dateFrom.value || null,
    dateTo: elements.dateTo.value || null
  };
  const response = await sendMessage({ type: "SET_FILTERS", filters });
  if (!response.ok) {
    showError(response.error || "Unable to apply filters.");
    return;
  }
  state.filters = filters;
  filtersDirty = false;
  updateFiltersUI({ centres: state.centres || [] });
}

async function clearFilters() {
  elements.centreSelect.selectedIndex = -1;
  elements.dateFrom.value = "";
  elements.dateTo.value = "";
  const filters = { centres: [], dateFrom: null, dateTo: null };
  const response = await sendMessage({ type: "SET_FILTERS", filters });
  if (!response.ok) {
    showError(response.error || "Unable to clear filters.");
    return;
  }
  state.filters = filters;
  filtersDirty = false;
  updateFiltersUI({ centres: state.centres || [] });
}

async function refreshCentresList() {
  if (elements.centresRefresh) {
    elements.centresRefresh.disabled = true;
  }
  const response = await sendMessage({ type: "REFRESH_CENTRES" });
  if (!response.ok) {
    showError(response.error || "Unable to refresh centres.");
    if (elements.centresRefresh) {
      elements.centresRefresh.disabled = false;
    }
    return;
  }
  state.centres = Array.isArray(response.centres) ? response.centres : [];
  updateFiltersUI({ centres: state.centres || [], preserveDraft: true });
  if (elements.centresRefresh) {
    elements.centresRefresh.disabled = false;
  }
}

function updateClickerCountdown() {
  const clicker = state.clicker || {};
  if (!clicker.running) {
    elements.clickerNext.textContent = "--";
    return;
  }
  const intervalMs = clicker.intervalMs || 8000;
  const nextIntervalMs = Number(clicker.nextIntervalMs) || intervalMs;
  const showRandom = !!clicker.nextIntervalRandomized && Number.isFinite(nextIntervalMs);
  let nextAt = clicker.nextClickAt
    ? new Date(clicker.nextClickAt).getTime()
    : clicker.lastClickAt
      ? new Date(clicker.lastClickAt).getTime() + intervalMs
      : clicker.startedAt
        ? new Date(clicker.startedAt).getTime() + intervalMs
        : null;
  if (!nextAt) {
    if (!fallbackNextAt || fallbackNextAt <= Date.now()) {
      fallbackNextAt = Date.now() + intervalMs;
    }
    nextAt = fallbackNextAt;
  } else {
    fallbackNextAt = 0;
  }
  const remainingMs = nextAt - Date.now();
  if (remainingMs <= 0) {
    elements.clickerNext.textContent = "Now";
    return;
  }
  const seconds = Math.max(1, Math.ceil(remainingMs / 1000));
  const intervalSeconds = Math.max(1, Math.round(nextIntervalMs / 1000));
  const suffix = showRandom ? ` (rnd ${intervalSeconds}s)` : "";
  elements.clickerNext.textContent = `${seconds}s${suffix}`;
}

function startCountdownTimer() {
  if (countdownTimer) {
    return;
  }
  countdownTimer = window.setInterval(() => {
    updateClickerCountdown();
  }, 1000);
}

function stopCountdownTimer() {
  if (countdownTimer) {
    window.clearInterval(countdownTimer);
    countdownTimer = null;
  }
}

function updateStatusUI() {
  if (!state.lastResult) {
    setStatus(state.running ? "unknown" : "idle");
    elements.lastChecked.textContent = "--";
    elements.signalCount.textContent = "0";
    updateDates([]);
    return;
  }

  const result = state.lastResult;
  setStatus(result.status || "unknown");
  elements.statusSummary.textContent = result.summary || STATUS_LOOKUP.unknown.summary;
  elements.lastChecked.textContent = formatTime(result.checkedAt);
  const signals = (result.dates?.length || 0) + (result.ctaFound ? 1 : 0);
  elements.signalCount.textContent = `${signals}`;
  updateDates(result.dates || []);
}

function addLogEntry(result) {
  if (!result) {
    return;
  }
  const entry = document.createElement("div");
  entry.className = "log-item";
  const time = formatTime(result.checkedAt);
  const title = document.createElement("strong");
  title.textContent = `${time} - ${result.status || "unknown"}`;
  const detail = document.createElement("span");
  detail.textContent = result.summary || "Scan completed.";
  entry.appendChild(title);
  entry.appendChild(detail);
  elements.logList.prepend(entry);

  while (elements.logList.children.length > 8) {
    elements.logList.removeChild(elements.logList.lastChild);
  }
}

function showError(message) {
  if (!message) {
    elements.errorBanner.hidden = true;
    return;
  }
  elements.errorBanner.textContent = message;
  elements.errorBanner.hidden = false;
  window.setTimeout(() => {
    elements.errorBanner.hidden = true;
  }, 5000);
}

function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response || {});
    });
  });
}

async function refreshState() {
  const response = await sendMessage({ type: "GET_STATE" });
  state.running = !!response.running;
  state.intervalMs = response.intervalMs || state.intervalMs;
  state.lastResult = response.lastResult || null;
  state.filters = response.filters || state.filters;
  state.autoNavigate = !!response.autoNavigate;
  state.clicker = response.clicker || state.clicker;
  elements.intervalInput.value = Math.round(state.intervalMs / 1000);
  updateControls();
  updateStatusUI();
  updateClickerUI();
  filtersDirty = false;
  updateFiltersUI({ centres: state.lastResult?.centres || state.centres || [] });
}

async function startMonitoring() {
  const intervalSec = Number(elements.intervalInput.value) || 30;
  const intervalMs = Math.min(Math.max(intervalSec, 10), 300) * 1000;
  const response = await sendMessage({ type: "START", intervalMs });
  if (!response.ok) {
    showError(response.error || "Unable to start monitoring on this tab.");
  }
}

async function stopMonitoring() {
  const response = await sendMessage({ type: "STOP" });
  if (!response.ok) {
    showError(response.error || "Unable to stop monitoring on this tab.");
  }
}

async function startClicker() {
  const fallbackInterval = Math.round((state.clicker?.intervalMs || 125000) / 1000);
  const fallbackTotal = state.clicker?.totalClicks || 3;
  const intervalSec = Number(elements.clickerInterval.value) || fallbackInterval;
  const totalClicks = Number(elements.clickerTotal.value) || fallbackTotal;
  const loop = !!elements.clickerLoop.checked;
  const clickFindAfter = !!elements.clickerSubmitAfter.checked || loop;
  const autoScroll = !!elements.clickerAutoScroll.checked;
  const intervalMs = Math.min(Math.max(intervalSec, 2), 300) * 1000;
  const totalClamped = Math.min(Math.max(totalClicks, 1), 100);
  const response = await sendMessage({
    type: "CLICKER_START",
    intervalMs,
    totalClicks: totalClamped,
    clickFindAfter,
    loop,
    autoScroll
  });
  if (!response.ok) {
    showError(response.error || "Unable to start the auto clicker on this tab.");
  }
}

async function stopClicker() {
  const response = await sendMessage({ type: "CLICKER_STOP" });
  if (!response.ok) {
    showError(response.error || "Unable to stop the auto clicker.");
  }
}

elements.startBtn.addEventListener("click", () => {
  showError("");
  primeAudio();
  startMonitoring();
});

elements.stopBtn.addEventListener("click", () => {
  showError("");
  stopMonitoring();
});

elements.clickerStart.addEventListener("click", () => {
  showError("");
  primeAudio();
  startClicker();
});

elements.clickerStop.addEventListener("click", () => {
  showError("");
  stopClicker();
});

elements.filtersApply.addEventListener("click", () => {
  showError("");
  applyFilters();
});

elements.filtersClear.addEventListener("click", () => {
  showError("");
  clearFilters();
});

elements.centresRefresh.addEventListener("click", () => {
  showError("");
  refreshCentresList();
});

elements.autoNavToggle.addEventListener("change", async () => {
  const autoNavigate = !!elements.autoNavToggle.checked;
  const response = await sendMessage({ type: "SET_AUTONAV", autoNavigate });
  if (!response.ok) {
    showError(response.error || "Unable to update auto-navigation.");
    elements.autoNavToggle.checked = !!state.autoNavigate;
    return;
  }
  state.autoNavigate = autoNavigate;
  updateFiltersUI({ centres: state.centres || [], preserveDraft: filtersDirty });
});

elements.centreSelect.addEventListener("change", () => {
  updateCentreOptionLabels();
  markFiltersDirty();
});

elements.centreSelect.addEventListener("mousedown", (event) => {
  const option = event.target;
  if (!(option instanceof HTMLOptionElement) || option.disabled) {
    return;
  }
  event.preventDefault();
  option.selected = !option.selected;
  updateCentreOptionLabels();
  markFiltersDirty();
});

elements.dateFrom.addEventListener("change", () => {
  reconcileDateRange("from");
  markFiltersDirty();
});

elements.dateTo.addEventListener("change", () => {
  reconcileDateRange("to");
  markFiltersDirty();
});

elements.clickerLoop.addEventListener("change", () => {
  if (elements.clickerLoop.checked) {
    elements.clickerSubmitAfter.checked = true;
    elements.clickerSubmitAfter.disabled = true;
    syncClickerPrefs(true, true);
  } else {
    elements.clickerSubmitAfter.disabled = false;
    syncClickerPrefs(elements.clickerSubmitAfter.checked, false);
  }
});

elements.clickerSubmitAfter.addEventListener("change", () => {
  const loop = elements.clickerLoop.checked;
  const clickFindAfter = elements.clickerSubmitAfter.checked || loop;
  syncClickerPrefs(clickFindAfter, loop);
});

elements.clickerAutoScroll.addEventListener("change", () => {
  syncAutoScrollPref(elements.clickerAutoScroll.checked);
});

elements.clickerInterval.addEventListener("change", () => {
  syncClickerPrefs(elements.clickerSubmitAfter.checked, elements.clickerLoop.checked);
});

elements.clickerTotal.addEventListener("change", () => {
  syncClickerPrefs(elements.clickerSubmitAfter.checked, elements.clickerLoop.checked);
});

chrome.runtime.onMessage.addListener((message, sender) => {
  const fromContent = !!sender?.tab;
  if (fromContent && (message?.type === "STATUS_UPDATE" || message?.type === "CLICKER_STATUS")) {
    return;
  }
  if (message?.type === "STATE_UPDATE") {
    state.running = !!message.state?.running;
    state.intervalMs = message.state?.intervalMs || state.intervalMs;
    state.lastResult = message.state?.lastResult || state.lastResult;
    state.filters = message.state?.filters || state.filters;
    state.autoNavigate = !!message.state?.autoNavigate;
    state.clicker = message.state?.clicker || state.clicker;
    elements.intervalInput.value = Math.round(state.intervalMs / 1000);
    updateControls();
    updateStatusUI();
    updateClickerUI();
    updateFiltersUI({
      centres: state.lastResult?.centres || state.centres || [],
      preserveDraft: filtersDirty
    });
  }

  if (message?.type === "STATUS_UPDATE") {
    const previousStatus = state.lastResult?.status;
    state.lastResult = message.result || state.lastResult;
    updateStatusUI();
    if (message.result?.changed || message.result?.reason === "manual" || message.result?.reason === "start") {
      addLogEntry(message.result);
    }
    if (state.lastResult?.status === "available" && (message.result?.changed || previousStatus !== "available")) {
      playChiptune();
    }
    if (state.lastResult?.status === "blocked" && (message.result?.changed || previousStatus !== "blocked")) {
      playWarningChiptune();
    }
    updateCentresList(
      message.result?.centres || state.centres || [],
      filtersDirty ? getSelectedCentres() : null
    );
  }

  if (message?.type === "CLICKER_STATUS") {
    state.clicker = message.clicker || state.clicker;
    updateClickerUI();
    if (state.clicker?.error) {
      showError(state.clicker.error);
    }
  }
});

refreshState();
